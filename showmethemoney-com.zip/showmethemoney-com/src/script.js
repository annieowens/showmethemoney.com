/* ------------------------
   INITIAL DATA
------------------------ */
let scholarships = [
  {
    id: 1,
    title: "STEM Research Grant",
    focus: "STEM",
    location: "USA",
    funding: "Full",
    deadline: "2025-09-30",
    description: "A grant for STEM research projects.",
    applyLink: "https://example.com/apply1"
  },
  {
    id: 2,
    title: "Humanities Fellowship",
    focus: "Humanities",
    location: "UK",
    funding: "Partial",
    deadline: "2025-10-15",
    description: "Funding for Humanities graduate students.",
    applyLink: "https://example.com/apply2"
  },
  {
    id: 3,
    title: "Social Sciences Scholarship",
    focus: "Social Sciences",
    location: "International",
    funding: "Grant",
    deadline: "2025-09-25",
    description: "Supports international social sciences students.",
    applyLink: "https://example.com/apply3"
  }
];

let likes = JSON.parse(localStorage.getItem("likes")) || [];
let comments = JSON.parse(localStorage.getItem("comments")) || [];
let currentUser = JSON.parse(localStorage.getItem("currentUser")) || null;

/* ------------------------
   PAGE NAVIGATION
------------------------ */
function showPage(pageId){
  document.querySelectorAll("main > section").forEach(sec=>{
    sec.classList.add("hidden");
  });
  document.getElementById("filtersBar").style.display = pageId==="home" ? "flex" : "none";
  document.getElementById("page-"+pageId).classList.remove("hidden");
  if(pageId==="home") renderCards();
  if(pageId==="likes") renderLikes();
  if(pageId==="timeline") renderTimeline();
  if(pageId==="discussion") renderDiscussion();
}

showPage("home");

/* ------------------------
   CARDS / DETAIL PAGE
------------------------ */
function renderCards(){
  const grid = document.getElementById("cardsGrid");
  grid.innerHTML = "";
  const searchVal = document.getElementById("searchInput").value.toLowerCase();
  const focusVal = document.getElementById("filterFocus").value;
  const locVal = document.getElementById("filterLocation").value;
  const fundVal = document.getElementById("filterFunding").value;

  scholarships.forEach(s=>{
    if(searchVal && !s.title.toLowerCase().includes(searchVal) && !s.description.toLowerCase().includes(searchVal)) return;
    if(focusVal && s.focus!==focusVal) return;
    if(locVal && s.location!==locVal) return;
    if(fundVal && s.funding!==fundVal) return;

    const card = document.createElement("div");
    card.className="card";
    const isClosingSoon = (new Date(s.deadline) - new Date())/1000/60/60/24 <= 7;
    card.innerHTML=`
      <h3>${s.title} ${isClosingSoon?"<span style='color:red'>(Closing Soon!)</span>":""}</h3>
      <p>${s.focus} | ${s.location} | ${s.funding}</p>
      <p>Deadline: ${s.deadline}</p>
    `;
    card.onclick=()=>showDetail(s.id);
    grid.appendChild(card);
  });
}

/* DETAIL PAGE */
function showDetail(id){
  const s = scholarships.find(x=>x.id===id);
  const container = document.getElementById("detailCard");
  const liked = likes.includes(id);
  container.innerHTML=`
    <h2>${s.title}</h2>
    <p>${s.focus} | ${s.location} | ${s.funding}</p>
    <p>Deadline: ${s.deadline}</p>
    <p>${s.description}</p>
    <div id="progress-bar"><div class="progress-inner" style="width:${calculateProgress(s.deadline)}%"></div></div>
    <button class="btn" onclick="window.open('${s.applyLink}','_blank')">Apply</button>
    <button class="btn outline" onclick="toggleLike(${id})">${liked?"❤️ Liked":"🤍 Like"}</button>
  `;
  showPage("detail");
}

/* Progress bar (days passed vs total period) */
function calculateProgress(deadline){
  const now = new Date();
  const end = new Date(deadline);
  const totalDays = (end-now)/1000/60/60/24;
  const passed = 1-Math.max(totalDays/60,0); // 60 days window
  return Math.min(Math.max(passed*100,0),100);
}

/* LIKE FUNCTION */
function toggleLike(id){
  if(likes.includes(id)){
    likes = likes.filter(x=>x!==id);
  } else {
    likes.push(id);
    showBadge(`Saved "${scholarships.find(s=>s.id===id).title}"`);
  }
  localStorage.setItem("likes",JSON.stringify(likes));
  showDetail(id);
}

/* BADGES */
function showBadge(text){
  const b = document.createElement("div");
  b.className="badge";
  b.innerText=text;
  document.getElementById("badge-container").appendChild(b);
  setTimeout(()=>b.remove(),3000);
}

/* ------------------------
   LIKES PAGE
------------------------ */
function renderLikes(){
  const grid = document.getElementById("likesGrid");
  grid.innerHTML="";
  likes.forEach(id=>{
    const s = scholarships.find(x=>x.id===id);
    const card = document.createElement("div");
    card.className="card";
    card.innerHTML=`<h3>${s.title}</h3><p>${s.focus} | ${s.location} | ${s.funding}</p>`;
    card.onclick=()=>showDetail(id);
    grid.appendChild(card);
  });
}

/* ------------------------
   TIMELINE
------------------------ */
function renderTimeline(){
  const bar = document.getElementById("timelineBar");
  bar.innerHTML="";
  const sorted = [...scholarships].sort((a,b)=>new Date(a.deadline)-new Date(b.deadline));
  sorted.forEach(s=>{
    const item = document.createElement("div");
    item.className="card";
    const isClosingSoon = (new Date(s.deadline) - new Date())/1000/60/60/24 <= 7;
    item.innerHTML=`
      <h4>${s.title}</h4>
      <p>${s.deadline} ${isClosingSoon?"<span style='color:red'>⚠️</span>":""}</p>
    `;
    item.onclick=()=>showDetail(s.id);
    bar.appendChild(item);
  });
}

/* ------------------------
   FILTERS + SEARCH
------------------------ */
document.getElementById("searchInput").addEventListener("input",renderCards);
document.getElementById("filterFocus").addEventListener("change",renderCards);
document.getElementById("filterLocation").addEventListener("change",renderCards);
document.getElementById("filterFunding").addEventListener("change",renderCards);
document.getElementById("clearFiltersBtn").addEventListener("click",()=>{
  document.getElementById("searchInput").value="";
  document.getElementById("filterFocus").value="";
  document.getElementById("filterLocation").value="";
  document.getElementById("filterFunding").value="";
  renderCards();
});

/* ------------------------
   DISCUSSION / COMMENTS
------------------------ */
function renderDiscussion(){
  const container = document.getElementById("global-comments-container");
  container.innerHTML="";
  comments.forEach((c,i)=>{
    const div = document.createElement("div");
    div.className="comment";
    div.innerHTML=`<strong>${c.user}</strong>: ${c.text} <span style="color:#888;font-size:0.8rem">(${c.time})</span>`;
    container.appendChild(div);
  });
}

document.getElementById("global-comment-submit").addEventListener("click",()=>{
  const input = document.getElementById("global-comment-input");
  if(input.value.trim()==="") return;
  const cmt = {
    user: currentUser ? currentUser.name : "Anonymous",
    text: input.value,
    time: new Date().toLocaleString()
  };
  comments.push(cmt);
  localStorage.setItem("comments",JSON.stringify(comments));
  input.value="";
  renderDiscussion();
});

/* ------------------------
   CHAT / HELP BUTTON
------------------------ */
const chatBtn = document.getElementById("chat-btn");
const chatBox = document.getElementById("chat-box");
document.getElementById("chat-close").addEventListener("click",()=>chatBox.classList.add("hidden"));
chatBtn.addEventListener("click",()=>chatBox.classList.toggle("hidden"));

/* Click FAQ items */
chatBox.querySelectorAll("li").forEach(li=>{
  li.addEventListener("click",()=>{
    document.getElementById("chat-input").value = li.dataset.response;
  });
});

/* ------------------------
   ACCORDION (GUIDES)
------------------------ */
document.querySelectorAll(".accordion h3").forEach(h=>{
  h.addEventListener("click",()=>{
    const content = h.nextElementSibling;
    content.style.display = content.style.display==="block" ? "none":"block";
  });
});

/* ------------------------
   SIGN UP / SIGN IN
------------------------ */
function openModal(id){document.getElementById(id).classList.remove("hidden");}
function closeModal(id){document.getElementById(id).classList.add("hidden");}

document.getElementById("signUpForm").addEventListener("submit",e=>{
  e.preventDefault();
  const user = {
    name: document.getElementById("suName").value,
    email: document.getElementById("suEmail").value,
    phone: document.getElementById("suPhone").value,
    optEmail: document.getElementById("suOptEmail").checked,
    optText: document.getElementById("suOptText").checked,
    userNumber: Date.now()
  };
  localStorage.setItem("currentUser",JSON.stringify(user));
  currentUser = user;
  closeModal("signUpModal");
  showBadge(`Welcome, ${user.name}!`);
  updateUserBadge();
});

document.getElementById("signInForm").addEventListener("submit",e=>{
  e.preventDefault();
  const email = document.getElementById("siEmail").value;
  if(currentUser && currentUser.email===email){
    showBadge(`Welcome back, ${currentUser.name}!`);
    updateUserBadge();
    closeModal("signInModal");
  } else {
    alert("User not found. Sign up first!");
  }
});

function updateUserBadge(){
  if(currentUser){
    document.getElementById("userBadge").classList.remove("hidden");
    document.getElementById("openSignInBtn").classList.add("hidden");
    document.getElementById("openSignUpBtn").classList.add("hidden");
    document.getElementById("userNameBadge").innerText = `Hi, ${currentUser.name}`;
  }
}
updateUserBadge();

const calendar = document.getElementById("advisor-calendar");
for(let d=1; d<=30; d++){
  const slot = document.createElement("div");
  slot.className="calendar-slot card";
  slot.innerText=`Sept ${d} 10am-4pm`;
  slot.onclick=()=>alert(`Appointment requested for Sept ${d}`);
  calendar.appendChild(slot);
}

/* SIGN OUT */
function signOut(){
  currentUser=null;
  localStorage.removeItem("currentUser");
  document.getElementById("userBadge").classList.add("hidden");
  document.getElementById("openSignInBtn").classList.remove("hidden");
  document.getElementById("openSignUpBtn").classList.remove("hidden");
}

/* ------------------------
   VISUAL CALENDAR
------------------------ */
const calendar = document.getElementById("calendar");
const timeSelection = document.getElementById("time-selection");
const timeDropdown = document.getElementById("time-dropdown");
const appointmentForm = document.getElementById("appointmentForm");
const confirmationDiv = document.getElementById("appointmentConfirmation");
const confirmationNumberSpan = document.getElementById("confirmationNumber");

let selectedDate = null;
let selectedTime = null;

// Generate current month's days
function generateCalendar(){
  calendar.innerHTML="";
  const today = new Date();
  const year = today.getFullYear();
  const month = today.getMonth();
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  
  for(let i=0;i<firstDay.getDay();i++) calendar.appendChild(document.createElement("div")); // empty days

  for(let d=1; d<=lastDay.getDate(); d++){
    const dayDiv = document.createElement("div");
    dayDiv.className="calendar-day";
    dayDiv.innerText=d;
    dayDiv.dataset.date = `${year}-${month+1}-${d}`;
    dayDiv.addEventListener("click",()=>{
      document.querySelectorAll(".calendar-day.selected").forEach(el=>el.classList.remove("selected"));
      dayDiv.classList.add("selected");
      selectedDate = dayDiv.dataset.date;
      showTimeSlots();
    });
    calendar.appendChild(dayDiv);
  }
}

generateCalendar();

// Show available time slots for selected day
function showTimeSlots(){
  timeDropdown.innerHTML="";
  const times = ["10:00","11:00","12:00","13:00","14:00","15:00","16:00"];
  times.forEach(t=>{
    const opt = document.createElement("option");
    opt.value=t;
    opt.innerText=t;
    timeDropdown.appendChild(opt);
  });
  timeSelection.classList.remove("hidden");
  appointmentForm.classList.remove("hidden");
}

// Auto-fill logged-in user info
timeDropdown.addEventListener("change", ()=>selectedTime=timeDropdown.value);
if(currentUser){
  document.getElementById("apptName").value = currentUser.name;
  document.getElementById("apptEmail").value = currentUser.email;
}

// Handle appointment submission
appointmentForm.addEventListener("submit", e=>{
  e.preventDefault();
  if(!selectedDate || !selectedTime) return alert("Please select a date and time!");

  const appointment = {
    name: document.getElementById("apptName").value,
    email: document.getElementById("apptEmail").value,
    notes: document.getElementById("apptNotes").value,
    zoom: document.getElementById("apptZoom").value || "Will be provided",
    datetime: `${selectedDate} ${selectedTime}`,
    confirmation: Math.floor(Math.random()*900000+100000)
  };

  // Save appointment (demo: localStorage)
  let appointments = JSON.parse(localStorage.getItem("appointments")) || [];
  appointments.push(appointment);
  localStorage.setItem("appointments", JSON.stringify(appointments));

  // Show confirmation
  appointmentForm.classList.add("hidden");
  confirmationDiv.classList.remove("hidden");
  confirmationNumberSpan.innerText = appointment.confirmation;

  // Trigger email (requires Apps Script backend)
  sendEmailNotification(appointment);
});

/* ------------------------
   EMAIL NOTIFICATION (Google Apps Script)
------------------------ */
function sendEmailNotification(appointment){
  // For demo, send fetch to your deployed Apps Script Web App
  fetch("YOUR_GOOGLE_SCRIPT_URL_HERE", {
    method:"POST",
    body: JSON.stringify(appointment)
  }).then(res=>{
    console.log("Email sent via Apps Script:", res.status);
  });
}

